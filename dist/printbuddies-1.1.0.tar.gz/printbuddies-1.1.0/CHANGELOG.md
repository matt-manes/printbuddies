# Changelog

## 1.0.1 (2023-02-13)

#### Fixes

* fix counter_override in error in ProgBar.display() if passed value is 0